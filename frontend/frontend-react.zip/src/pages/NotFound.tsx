export default function NotFound() {
  return <div className="h-body all-center">404 - NotFound</div>;
}
